//
//  ViewController.swift
//  Flixster
//
//  Created by user190022 on 1/31/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

